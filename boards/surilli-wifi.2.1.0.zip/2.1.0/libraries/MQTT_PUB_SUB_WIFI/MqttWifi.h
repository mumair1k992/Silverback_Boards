/*
  mqtts.h - Library for receiving message.
  Created by Junaid Alam at Silverback pvt limited, August 25, 2017.
  Released into the public domain.
*/



#ifndef MqttWifi_h
#define MqttWifi_h

#include "Arduino.h"
#include <ESP8266WiFi.h>


class mqttsWifi
{
  public:
    mqttsWifi(char* clientId, char* brokerUrl, int brokerPort, char* ssid, char* password);
    void Publish(char* topic, char* message);
	void Subscribe(char*topic);
	void Connect();
    void mySerial_read();
    boolean isGPRSReady();
  
  
  public:
String gprsStr = "";
int index = 0;
byte data1;
char atCommand[50];
byte mqttMessage[127];
int mqttMessageLength = 0;

char* _message;
char* _topic;
int _brokerPort;
char* _brokerUrl;
char* _clientId;
char* _ssid;
char* _password;
WiFiClient client;

//bolean flags
boolean smsReady = false;
boolean smsSent = false;
boolean gprsReady = false;
boolean mqttSent = false;
};

#endif
