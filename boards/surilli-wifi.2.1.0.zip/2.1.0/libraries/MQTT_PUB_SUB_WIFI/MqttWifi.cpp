/*
  mqttP.h - Library for Publishing MQTT messages.
  Created by Silverback pvt limited, August 25, 2017.
  Released into the public domain.
*/



#include "Arduino.h"
#include "MqttWifi.h"
#include "mqtt.h"
#include <SoftwareSerial.h>
#include <string.h>
#include <ESP8266WiFi.h>

using namespace std;

mqttsWifi::mqttsWifi(char* clientId, char* brokerUrl, int brokerPort, char* ssid, char* password)
{
	_brokerPort=brokerPort;
	_brokerUrl=brokerUrl;
	_clientId=clientId;
	_ssid=ssid;
	_password=password;
	
	
	
	

}

void mqttsWifi::Connect()
{
	
	WiFi.begin(_ssid, _password);
	delay(5000);
	client.connect(_brokerUrl, _brokerPort);
	
      
      
    
 mqttMessageLength = 16 + strlen(_clientId);
 Serial.println(mqttMessageLength);
 mqtt_connect_message(mqttMessage, _clientId);

 for (int j = 0; j < mqttMessageLength; j++) {
 client.write(mqttMessage[j]); // Message contents
 //client.write(mqttMessage[j]); // Message contents
 }
 
 delay(500);
 
  }
  
void mqttsWifi::Publish(char* topic, char* message)
{

	_topic=topic;
	_message=message;
  
  
 
 mqttMessageLength = 4 + strlen(_topic) + strlen(_message);
 Serial.println(mqttMessageLength);
 mqtt_publish_message(mqttMessage, _topic, _message);


 for (int k = 0; k < mqttMessageLength; k++) {
 client.write(mqttMessage[k]);
 }

 
}  

void mqttsWifi::Subscribe(char* topic)
{
	Serial.begin(9600);
	_topic=topic;
	Serial.println(_topic);


	mqttMessageLength = 7 + strlen(_topic);
	Serial.println(mqttMessageLength);
	mqtt_subscribe_message(mqttMessage, _topic);

	for (int k = 0; k < mqttMessageLength; k++) {
		client.write(mqttMessage[k]);
	}
	Serial.begin(9600);
	int start = millis();
	int end = start + 10000;

	while (end > millis()) {
		
		if (client.available()>0) {
			Serial.write(client.read());

		}
	}
} 


void mqttsWifi::mySerial_read()

	{ 
		SoftwareSerial mySerial(8, 9); // RX, TX
  
  	mySerial.begin(9600);
  	delay(10);
	
		if (mySerial.available() > 0) 
		{
          
         String letter = mySerial.readString();
         
         Serial.println(letter);
         
        }
        delay(1000);
	}





