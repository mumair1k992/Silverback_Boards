/*
  mqttP.h - Library for Publishing MQTT messages.
  Created by Silverback pvt limited, August 25, 2017.
  Released into the public domain.
*/



#include "Arduino.h"
#include "MqttWifi.h"
#include "TCPClient.h"


TCPClient::TCPClient(char* Url, int Port, char* ssid, char* password)
{
	Serial.begin(9600);
	_Port = Port;
	_Url = Url;
	_ssid = ssid;
	_password = password;

}

void TCPClient::Connect()
{

	WiFi.begin(_ssid, _password);
	delay(5000);

	client.connect(_Url, _Port);

}

void TCPClient::Send(char* message)
{
	_message = message;

	client.write(&_message[0], 1+(sizeof(_message)));
	Serial.println("Message Sent");
      
}

char TCPClient::Receive()
{
	char msg;
	if (client.available() > 0) {
		msg = client.read();

		return msg;
	}
}








