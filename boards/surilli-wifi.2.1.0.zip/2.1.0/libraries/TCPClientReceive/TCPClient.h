/*
  mqtts.h - Library for receiving message.
  Created by Junaid Alam at Silverback pvt limited, August 25, 2017.
  Released into the public domain.
*/



#ifndef TCPClient_h
#define TCPClient_h

#include "Arduino.h"
#include <ESP8266WiFi.h>


class TCPClient
{
public:
	TCPClient(char* Url, int Port, char* ssid, char* password);
	void Connect();
	void Send(char* message);
	char Receive();
	void mySerial_read();



public:

	char* _message;
	int _Port;
	char* _Url;
	char* _ssid;
	char* _password;
	WiFiClient client;
};


#endif
