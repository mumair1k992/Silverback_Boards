
#include "Arduino.h"
#include "SurilliCloudWifi.h"
#include "mqtt.h"
#include <SoftwareSerial.h>
#include <string.h>
#include <ESP8266WiFi.h>

using namespace std;

SurilliCloudWifi::SurilliCloudWifi(char* ssid, char* password)
{
	char s[18];
	String k = WiFi.macAddress();
	k.toCharArray(s, 18);
	char p[40];
	sprintf(p, "SurilliClientID%s", s);


	_brokerPort = 1883;
	_brokerUrl = "18.195.229.81";
	_clientId = p;
	_ssid = ssid;
	_password = password;

}

void SurilliCloudWifi::Connect()
{

	WiFi.begin(_ssid, _password);
	delay(5000);
	client.connect(_brokerUrl, _brokerPort);




	mqttMessageLength = 16 + strlen(_clientId);
	Serial.println(mqttMessageLength);
	mqtt_connect_message(mqttMessage, _clientId);

	for (int j = 0; j < mqttMessageLength; j++) {
		client.write(mqttMessage[j]); // Message contents
									  //client.write(mqttMessage[j]); // Message contents
	}

	delay(500);

}

void SurilliCloudWifi::Send(char* message)
{




	char s[18];
	String k = WiFi.macAddress();
	int x = k.length();
	k = k.substring(x-11, x);
	k.remove(2,1);
	k.remove(4,1);
	k.remove(6,1);

	Serial.println(k);
	k.toCharArray(s, 18);
	Serial.println(s);

	_topic = s;
	_message = message;


	mqttMessageLength = 4 + strlen(_topic) + strlen(_message);
	Serial.println(mqttMessageLength);
	mqtt_publish_message(mqttMessage, _topic, _message);


	for (int k = 0; k < mqttMessageLength; k++) {
		client.write(mqttMessage[k]);
	}


}

void SurilliCloudWifi::Receive()
{
	char s[18];
	String k = WiFi.macAddress();
	int x = k.length();
	k = k.substring(x - 11, x);
	k.remove(2, 1);
	k.remove(4, 1);
	k.remove(6, 1);


	k.toCharArray(s, 18);
	Serial.println(s);

	Serial.begin(9600);
	_topic = s;
	Serial.println(s);


	mqttMessageLength = 7 + strlen(_topic);
	Serial.println(mqttMessageLength);
	mqtt_subscribe_message(mqttMessage, _topic);

	for (int k = 0; k < mqttMessageLength; k++) {
		client.write(mqttMessage[k]);
	}
	Serial.begin(9600);
	int start = millis();
	int end = start + 10000;

	while (end > millis()) {
		if (client.available()>0) {
			Serial.write(client.read());

	}
		}
}




void SurilliCloudWifi::mySerial_read()

{
	SoftwareSerial mySerial(8, 9); // RX, TX

	mySerial.begin(9600);
	delay(10);

	if (mySerial.available() > 0)
	{

		String letter = mySerial.readString();

		Serial.println(letter);

	}
	delay(1000);
}





