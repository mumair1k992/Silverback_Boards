



#ifndef SurilliCloudWifi_h
#define SurilliCloudWifi_h

#include "Arduino.h"
#include <ESP8266WiFi.h>


class SurilliCloudWifi
{
public:
	SurilliCloudWifi(char* ssid, char* password);
	void Send(char* message);
	void Receive();
	void Connect();
	void mySerial_read();
	boolean isGPRSReady();


public:
	String gprsStr = "";
	int index = 0;
	byte data1;
	char atCommand[50];
	byte mqttMessage[127];
	int mqttMessageLength = 0;

	char* _message;
	char* _topic;
	int _brokerPort;
	char* _brokerUrl;
	char* _clientId;
	char* _ssid;
	char* _password;
	WiFiClient client;

};

#endif
