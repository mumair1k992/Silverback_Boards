/*
  Button.h - Library for flashing led on the press of a button.
  Created by Silverback pvt limited, August 22, 2017.
  Released into the public domain.
*/

#include "Arduino.h"
#include "Button.h"

Button::Button(int ledpin, int buttonpin)
{
	_led = ledpin;
  _button = buttonpin;
   
  pinMode(_led, OUTPUT);
  
  pinMode(_button, INPUT);

}

void Button::exec()
{
	int buttonState = 0;
  buttonState = digitalRead(_button);

  // check if the pushbutton is pressed.
  // if it is, the buttonState is HIGH:
  if (buttonState == HIGH) {
    // turn LED on:
    digitalWrite(_led, HIGH);
  } else {
    // turn LED off:
    digitalWrite(_led, LOW);
  }  
}


