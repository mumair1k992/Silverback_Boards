/*
  SmsReceive.h - Library for receiving message.
  Created by Silverback pvt limited, August 25, 2017.
  Released into the public domain.
*/
#include "Arduino.h"
#include "SmsReceive.h"
#include <SoftwareSerial.h>

SmsReceive::SmsReceive(String num)
{
  	_num= num;
}

char SmsReceive::Setup()
{
	
SoftwareSerial mySerial(8, 9); // RX, TX
mySerial.begin(9600);
delay(10);
  
mySerial.println("AT+CMGF=1"); 
mySerial_read();
delay(1000);

mySerial.println("AT+CFUN=1");  
mySerial_read();
delay(1000);

mySerial.println(" AT+CSCS= \"GSM\" ");
mySerial_read();
delay(1000);
}

String SmsReceive::Receive()
{	

	
SoftwareSerial mySerial(8, 9); // RX, TX
mySerial.begin(9600);
delay(10);

mySerial.println("AT+CMGR=1");
_msg=mySerial_read();
delay(1000);

int m =0;
int size = _msg.length();
int z =0;

//Extract message
for (int j = 0; j<size; j++)
{
	if (_msg[j]=='+')
	{
		z = z+1;		
	}
	else if (z==4)
	{
		m=j;
		break;
	}
}
for (int i=m+5; i<=size-8; i++)
{
	no[i-(m+5)]= _msg[i];
}

int l=0;
//Extract number
for (int j = 0; j<size; j++)
{
	if (_msg[j]==',')
	{
		l = j;
		break;		
	}
}
for (int i=l+2; i<=l+14; i++)
{
	n[i-(l+2)]= _msg[i];
}


for (int i=0;i<3;i++)
{
	ss[i]=no[i];
}
String aa = ss;
String a=n;


if (aa!="GR=" && (_num==a||_num=="0000"))
{
mySerial.println("AT+CMGD=1, 4");
mySerial_read();
delay(1000);
return no;
}

else if (aa!="GR=" && _num!=a)
{
mySerial.println("AT+CMGD=1, 4");
mySerial_read();
delay(1000);
	for (int i= 0; i<200;+i++)
	{
		no[i]= NULL;
	}
	return "No New Message";
}

else if (aa=="GR=")
{
	for (int i= 0; i<200;+i++)
	{
		no[i]= NULL;
	}
	return "No New Message";
}

}


String SmsReceive::mySerial_read()

	{ String letter;
		SoftwareSerial mySerial(8, 9); // RX, TX
  
  	mySerial.begin(9600);
  	delay(10);
	
		if (mySerial.available() > 0) 
		{
         letter = mySerial.readString();
         
        //Serial.println(letter);
         
        }
        delay(1000);
       return (letter);
	   	}
	
	
	


