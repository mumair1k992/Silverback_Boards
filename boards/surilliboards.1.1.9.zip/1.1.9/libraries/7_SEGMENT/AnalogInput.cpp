/*
  AnalogInput - Library for taking input from a sensor and returning it's value to the program.
  Created by Silverback pvt limited, August 24, 2017.
  Released into the public domain.
*/

#include "Arduino.h"
#include "AnalogInput.h"

AnalogInput::AnalogInput(int pinIN, int pinOUT)
{
  _pinIN= pinIN;
  _pinOUT = pinOUT;
    
  pinMode(_pinOUT, OUTPUT);


}

int AnalogInput::exec()
{
  // read the value from the sensor:
  
  valueSensor = analogRead(_pinIN);
  
  delay(1000);
  
  return(valueSensor);  
}
