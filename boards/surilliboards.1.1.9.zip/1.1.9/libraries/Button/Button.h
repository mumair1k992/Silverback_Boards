/*
  Button.h - Library for flashing led on the press of a button.
  Created by Silverback pvt limited, August 22, 2017.
  Released into the public domain.
*/

#ifndef Button_h
#define Button_h

#include "Arduino.h"

class Button
{
  public:
    Button(int ledpin, int buttonpin);
    void exec();
  private:
    int _led;
	int _button;
};

#endif
