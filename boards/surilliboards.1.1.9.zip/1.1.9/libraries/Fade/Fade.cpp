/*
  Fade.h - Library for fading of led (FadeOut and FadeIn) .
  Created by Silverback pvt limited, August 22, 2017.
  Released into the public domain.
*/


#include "Arduino.h"
#include "Fade.h"

Fade::Fade(int pin, int b, int fa)
{

  pinMode(pin, OUTPUT);
  _pin = pin;
  bright = b;
  fade_amount = fa;
  pinMode(_pin, OUTPUT);
}

void Fade::exec()

{
	pinMode(_pin, OUTPUT);
  // set the brightghtness of pin:
  analogWrite(_pin, bright);
 
  // change the brightghtness for next time through the loop:
  bright = bright + fade_amount;
 
  // reverse the direction of the fading at the ends of the fade:
  if (bright == 0 || bright == 255) {
    fade_amount = -fade_amount ;
  }
  // wait for 30 milliseconds to see the dimming effect
  delay(30);  
}

