/*
 * SURILLIPlatStd.h -- standard AVR/Arduino platform.
 *
 * This is part of the library for the Silverback SURILLI Cellular Module
 *
 * Silverback invests time and resources providing this open source code,
 * please support Silverback and open-source hardware by purchasing
 * products from Silverback!
 *
 *
 * the Silverback_SURILLI_Library and released under the
 * license, all text above must be included in any redistribution.
 *
 *  Created on: 
 *      Author: 
 */


#ifndef SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_PLATFORM_SURILLIPLATSTD_H_
#define SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_PLATFORM_SURILLIPLATSTD_H_

#include "../SURILLIConfig.h"


#if (ARDUINO >= 100)
  #include "Arduino.h"
  #if !defined(__SAM3X8E__) && !defined(ARDUINO_ARCH_SAMD)  // Arduino Due doesn't support     #include <SoftwareSerial.h>
  #endif
#else
  #include "WProgram.h"
  #include <NewSoftSerial.h>
#endif

#include <avr/pgmspace.h>


// DebugStream	sets the Stream output to use
// for debug (only applies when SILVERBACK_SURILLI_DEBUG
// is defined in config)
#define DebugStream		Serial

#ifdef SILVERBACK_SURILLI_DEBUG
// need to do some debugging...
#define DEBUG_PRINT(...)		DebugStream.print(__VA_ARGS__)
#define DEBUG_PRINTLN(...)		DebugStream.println(__VA_ARGS__)
#endif

// a few typedefs to keep things portable
typedef	Stream 						SURILLIStreamType;
typedef const __FlashStringHelper *	SURILLIFlashStringPtr;

#define prog_char  					char PROGMEM

#define prog_char_strcmp(a, b)					strcmp_P((a), (b))
// define prog_char_strncmp(a, b, c)				strncmp_P((a), (b), (c))
#define prog_char_strstr(a, b)					strstr_P((a), (b))
#define prog_char_strlen(a)						strlen_P((a))
#define prog_char_strcpy(to, fromprogmem)		strcpy_P((to), (fromprogmem))
//define prog_char_strncpy(to, from, len)		strncpy_P((to), (fromprogmem), (len))

#endif /* SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_PLATFORM_SURILLIPLATSTD_H_ */
