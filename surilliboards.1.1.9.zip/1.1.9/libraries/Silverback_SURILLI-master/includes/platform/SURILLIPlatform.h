/*
 * SURILLIPlatform.h -- platform definitions includes.
 *
 * This is part of the library for the Silverback SURILLI Cellular Module
 *
 * Silverback invests time and resources providing this open source code,
 * please support Silverback and open-source hardware by purchasing
 * products from Silverback!
 *
 * Written by Pat Deegan, http://flyingcarsandstuff.com, for inclusion in
 * the Silverback_SURILLI_Library and released under the
 *license, all text above must be included in any redistribution.
 *
 *  Created on: 
 *      Author: 
 */


#ifndef SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_PLATFORM_SURILLIPLATFORM_H_
#define SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_PLATFORM_SURILLIPLATFORM_H_

#include "../SURILLIConfig.h"

// only "standard" config supported in this release -- namely AVR-based arduino type affairs
#include "SURILLIPlatStd.h"



#ifndef DEBUG_PRINT
// debug is disabled

#define DEBUG_PRINT(...)
#define DEBUG_PRINTLN(...)

#endif


#ifndef prog_char_strcmp
#define prog_char_strcmp(a, b)					strcmp((a), (b))
#endif

#ifndef prog_char_strstr
#define prog_char_strstr(a, b)					strstr((a), (b))
#endif

#ifndef prog_char_strlen
#define prog_char_strlen(a)						strlen((a))
#endif


#ifndef prog_char_strcpy
#define prog_char_strcpy(to, fromprogmem)		strcpy((to), (fromprogmem))
#endif


#endif /* SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_PLATFORM_SURILLIPLATFORM_H_ */
