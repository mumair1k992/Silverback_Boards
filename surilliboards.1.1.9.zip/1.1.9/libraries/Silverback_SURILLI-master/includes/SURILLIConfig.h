/*
 * SURILLIConfig.h -- compile-time configuration
 * This is part of the library for the Silverback SURILLI Cellular Module
 *
 * 
 * Silverback invests time and resources providing this open source code,
 * please support Silverback and open-source hardware by purchasing
 * products from Silverback!
 *
 * the Silverback_SURILLI_Library and released under the
 * license, all text above must be included in any redistribution.
 *
 *  Created on: 
 *      Author: 
 */

#ifndef SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_SURILLICONFIG_H_
#define SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_SURILLICONFIG_H_

/* SILVERBACK_SURILLI_DEBUG
 * When defined, will cause extensive debug output on the
 * DebugStream set in the appropriate platform/ header.
 */

#define SILVERBACK_SURILLI_DEBUG


#endif /* SILVERBACK_SURILLI_LIBRARY_SRC_INCLUDES_SURILLICONFIG_H_ */
