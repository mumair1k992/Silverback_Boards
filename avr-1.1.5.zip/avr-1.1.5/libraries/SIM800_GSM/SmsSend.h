/*
  SmsSend.cpp - Library for sending message to some GSM number (SoS).
  Created by Silverback pvt limited, August 21, 2017.
  Released into the public domain.
*/


#ifndef SmsSend_h
#define SmsSend_h

#include "Arduino.h"



class SmsSend
{
  public:
    SmsSend(String num, String msg);
    String exec();
    void mySerial_read();
  private:
    String _num;
	String _msg ;
	char var;
};

#endif
