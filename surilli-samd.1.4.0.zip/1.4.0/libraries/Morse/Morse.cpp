/*
  Morse.h - Library for flashing Morse code (SoS).
  Created by Silverback pvt limited, August 21, 2017.
  Released into the public domain.
*/

#include "Arduino.h"
#include "Morse.h"
  

Morse::Morse(int pin)
{
  pinMode(pin, OUTPUT);
  _pin = pin;
}

void Morse::dot()
{
   _pin=13;		
  digitalWrite(_pin, HIGH);
  delay(1000);
  digitalWrite(_pin, LOW);
  delay(1000);  
}

void Morse::dash()
{
  int r = ((rand() % 50) * 10);
  digitalWrite(_pin, HIGH);
  delay(r);
  digitalWrite(_pin, LOW);
  delay(r);
}
