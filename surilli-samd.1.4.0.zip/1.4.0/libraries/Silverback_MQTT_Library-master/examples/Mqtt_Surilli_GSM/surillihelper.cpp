#include <Silverback_SleepyDog.h>
#include <SoftwareSerial.h>
#include "Silverback_SURILLI.h"

#define halt(s) { Serial.println(F( s )); while(1);  }

extern Silverback_SURILLI surilli;
extern SoftwareSerial surilliSS;

boolean SURILLIconnect(const __FlashStringHelper *apn, const __FlashStringHelper *username, const __FlashStringHelper *password) {
  Watchdog.reset();

  Serial.println(F("Initializing SURILLI....(May take 3 seconds)"));
  
  surilliSS.begin(4800); // if you're using software serial
  
  if (! surilli.begin(surilliSS)) {           // can also try surilli.begin(Serial1) 
    Serial.println(F("Couldn't find SURILLI"));
    return false;
  }
  surilliSS.println("AT+CMEE=2");
  Serial.println(F("SURILLI is OK"));
  Watchdog.reset();
  Serial.println(F("Checking for network..."));
  while (surilli.getNetworkStatus() != 1) {
   delay(500);
  }

  Watchdog.reset();
  delay(5000);  // wait a few seconds to stabilize connection
  Watchdog.reset();
  
  surilli.setGPRSNetworkSettings(apn, username, password);

  Serial.println(F("Disabling GPRS"));
  surilli.enableGPRS(false);
  
  Watchdog.reset();
  delay(5000);  // wait a few seconds to stabilize connection
  Watchdog.reset();

  Serial.println(F("Enabling GPRS"));
  if (!surilli.enableGPRS(true)) {
    Serial.println(F("Failed to turn GPRS on"));  
    return false;
  }
  Watchdog.reset();

  return true;
}
