/*
  Fade.h - Library for fading of led (FadeOut and FadeIn) .
  Created by Silverback pvt limited, August 22, 2017.
  Released into the public domain.
*/


#ifndef Forse_h
#define Forse_h

#include "Arduino.h"

class Fade
{
  public:
    Fade(int pin, int b, int fa);
    void exec();
  private:
    int _pin;
    int bright;
    int fade_amount;
};

#endif
