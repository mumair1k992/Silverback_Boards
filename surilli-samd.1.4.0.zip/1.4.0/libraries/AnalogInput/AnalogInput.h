/*
  AnalogInput - Library for taking input from a sensor and returning it's value to the program.
  Created by Silverback pvt limited, August 24, 2017.
  Released into the public domain.
*/

#ifndef AnalogInput_h
#define AnalogInput_h

#include "Arduino.h"

class AnalogInput
{
  public:
    AnalogInput(int pinIN, int pinOUT);
    int exec();
  private:
    int _pinIN;
	int _pinOUT;
	int valueSensor;
};

#endif
