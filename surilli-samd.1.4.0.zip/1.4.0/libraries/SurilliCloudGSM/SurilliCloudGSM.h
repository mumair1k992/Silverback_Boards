



#ifndef SurilliCloudGSM_h
#define SurilliCloudGSM_h

#include "Arduino.h"


class SurilliCloudGSM
{
  public:
    SurilliCloudGSM(char* apn);
    void Publish(char* message);
    void Subscribe();
	void Connect();
	void Disconnect();
    String mySerial_read();
    boolean isGPRSReady();
  
  
  public:
String gprsStr = "";
int index = 0;
byte data1;
char atCommand[50];
byte mqttMessage[127];
int mqttMessageLength = 0;

char* _message;
char* _topic;
char* _brokerPort;
char* _brokerUrl;
char* _clientId;
char* _apn;


//bolean flags
boolean smsReady = false;
boolean smsSent = false;
boolean gprsReady = false;
boolean mqttSent = false;
};

#endif
